# Computer Lab Equipment Allocation and Fault Reporting System

equipment = {
    "Computer": 20,
    "Keyboard": 20,
    "Mouse": 20,
    "Monitor": 20,
    "Projector": 2
}

fault_reports = []

def view_equipment():
    print("\n--- Available Lab Equipment ---")
    for item, quantity in equipment.items():
        print(f"{item}: {quantity}")

def allocate_equipment():
    item = input("Enter equipment name: ").title()
    try:
        quantity = int(input("Enter quantity required: "))
    except ValueError:
        print("Please enter a valid number.")
        return

    if item not in equipment:
        print("Equipment not found.")
    elif quantity <= 0:
        print("Quantity must be greater than zero.")
    elif quantity <= equipment[item]:
        equipment[item] -= quantity
        print("Equipment allocated successfully!")
    else:
        print("Insufficient equipment available.")

def report_fault():
    item = input("Enter faulty equipment name: ").title()
    problem = input("Describe the fault: ").strip()

    if not item or not problem:
        print("Equipment name and fault description are required.")
        return

    fault_reports.append({
        "Equipment": item,
        "Problem": problem,
        "Status": "Pending"
    })
    print("Fault reported successfully!")

def view_faults():
    print("\n--- Fault Reports ---")
    if not fault_reports:
        print("No fault reports available.")
        return

    for number, report in enumerate(fault_reports, start=1):
        print(f"{number}. Equipment: {report['Equipment']}")
        print(f"   Problem: {report['Problem']}")
        print(f"   Status: {report['Status']}")

def main():
    while True:
        print("\n===== COMPUTER LAB MANAGEMENT =====")
        print("1. View Equipment")
        print("2. Allocate Equipment")
        print("3. Report Fault")
        print("4. View Fault Reports")
        print("5. Exit")

        choice = input("Enter your choice: ").strip()

        if choice == "1":
            view_equipment()
        elif choice == "2":
            allocate_equipment()
        elif choice == "3":
            report_fault()
        elif choice == "4":
            view_faults()
        elif choice == "5":
            print("Thank you!")
            break
        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()
