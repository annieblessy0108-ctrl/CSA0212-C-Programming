# Computer Lab Equipment Allocation and Fault Reporting System

## Requirements
- Python 3.x
- No external packages required

## How to run
1. Extract the ZIP file.
2. Open a terminal or Command Prompt in the extracted folder.
3. Run: `python main.py`

## Features
1. View available equipment
2. Allocate equipment
3. Report equipment faults
4. View fault reports

## Note
This is a beginner-friendly console prototype. Data is stored in memory and resets when the program exits.
